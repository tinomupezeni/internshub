# interns/apps.py (or __init__.py)
# No code needed here, just an empty file
