from django.http import JsonResponse
from interns.models import CompDepartment, Company, StudentProfile, StudentProject
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import (
    api_view,
    authentication_classes,
    permission_classes,
)

@api_view(["GET"])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def get_interns_data(request):
    if request.method == "GET":
        user = request.user
        company = Company.objects.get(user=user)

        # Get the company's department
        company_department = CompDepartment.objects.get(company=company)

        # Retrieve students with the same department
        students_with_same_department = StudentProfile.objects.filter(
            department=company_department.department
        )

        # Create a dictionary to hold student data
        studentData = {
            "department_name": company_department.department.deptName,
            "students": [],
        }

        # Populate student data if there are matching students
        if students_with_same_department.exists():
            for student_profile in students_with_same_department:
                student = student_profile.student
                project_count = StudentProject.objects.filter(student=student).count()
                studentData["students"].append(
                    {
                        "studentName": student.studentName,
                        "studentId": student.studentId,
                        "studentSurname": student.studentSurname,
                        "studentEmail": student.studentEmail,
                        "program": student_profile.program,
                        "institution": student_profile.institution.instName,
                        "projectCount": project_count,
                    }
                )

        return JsonResponse(studentData, safe=False)

    else:
        return JsonResponse({"error": "Invalid request method"}, status=405)
