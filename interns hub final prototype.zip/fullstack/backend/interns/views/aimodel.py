import random
import numpy as np
import pandas as pd
from sklearn.calibration import LabelEncoder
from interns.models import CompDepartment, StudentProfile, Student, DeptRequirement
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from rest_framework.decorators import (
    api_view,
    authentication_classes,
    permission_classes,
)
from sklearn.metrics.pairwise import cosine_similarity
import pickle

# Load the model and label encoder at the start of the application
MODEL_PATH = "ai_model/model_rf.pkl"

with open(MODEL_PATH, "rb") as file:
    le, rf = pickle.load(file)

# Load project descriptions
df = pd.read_csv("ai_model/student_projects0.csv")
project_descriptions = np.array(df["description"])

X = df[["program"]]
y = df["description"]


def recommend_projects(study_program, num_projects=3):
    study_program_encoded = le.transform([study_program])
    X_new = pd.DataFrame({"program": study_program_encoded})
    predicted_probabilities = rf.predict_proba(X_new)
    all_project_indices = range(len(y))
    random_project_indices = random.sample(all_project_indices, num_projects)

    recommended_projects = [y[i] for i in random_project_indices]
    return recommended_projects


def get_random_projects(n=3):
    unique_projects_df = df.drop_duplicates(subset=["project"])
    random_projects = unique_projects_df.sample(n=min(n, len(unique_projects_df)))
    return random_projects["project"].tolist()


@api_view(["GET"])
@authentication_classes([JWTAuthentication])
@permission_classes([IsAuthenticated])
def predict_view(request):
    if request.method == "GET":
        user = request.user
        student = Student.objects.get(user=user)

        student_profile = StudentProfile.objects.get(student=student)
        student_program = student_profile.program if student_profile else None
        student_department = StudentProfile.objects.get(student=student).department
        print(student_program.title())
        if student_program:
            recommended_projects = recommend_projects(
                student_program.title(), num_projects=3
            )
            response_data = {
                "projects": recommended_projects,
                "message": "some projects might not be as accurate as possible",
            }
            return JsonResponse(response_data, safe=False)
        else:
            random_projects = get_random_projects()
            response_data = {
                "projects": random_projects,
                "message": "Please add your study program in your profile to get more accurate projects",
            }
            return JsonResponse(response_data, safe=False)


# Load the model and data at the start of the application
MODEL_PATH_COMP = "ai_model/comp_project.pkl"

with open(MODEL_PATH_COMP, "rb") as file:
    vectorizer, project_descriptions, df = pickle.load(file)


def get_recommendations(student_program, company_requirements, top_n=3):
    # Preprocess the student program and company requirements
    query = vectorizer.transform([student_program, company_requirements])

    # Compute the cosine similarity between the query and project descriptions
    cosine_similarities = cosine_similarity(query, project_descriptions)

    # Compute the average cosine similarity for each project
    average_similarities = cosine_similarities.mean(axis=0)

    # Get the indices of the top-n most similar projects
    top_indices = average_similarities.argsort()[: -top_n - 1 : -1]

    # Get the top recommended projects
    top_projects = df.loc[top_indices[:top_n], "project"]

    # Filter out duplicate projects
    unique_projects = []
    for project in top_projects:
        if project not in unique_projects:
            unique_projects.append(project)

    return unique_projects[:3]  # Return the top 3 projects


def predict_comp_view(user):
    student = Student.objects.get(user=user)
    student_profile = StudentProfile.objects.get(student=student)
    student_program = student_profile.program
    student_department = student_profile.department

    companies_with_same_department = CompDepartment.objects.filter(
        department=student_department
    )

    requirements = []
    for comp_dept in companies_with_same_department:
        company_requirements = DeptRequirement.objects.filter(
            department=student_department
        ).values_list("requirement__requirement", flat=True)
        requirements.extend(company_requirements)

    # Join all requirements into a single string
    combined_requirements = " ".join(requirements)

    # Make recommendations
    recommended_projects = get_recommendations(student_program, combined_requirements)

    return recommended_projects

