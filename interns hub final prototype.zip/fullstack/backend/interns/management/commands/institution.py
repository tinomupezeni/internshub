from django.core.management.base import BaseCommand
from interns.models import Institution


class Command(BaseCommand):
    help = "Load departments into the database"

    def handle(self, *args, **kwargs):
        institution = [
                "University of Zimbabwe (Harare)",
                "Midlands State University (Gweru)",
                "Africa University (Mutare)",
                "National University of Science and Technology (Bulawayo)",
                "Chinhoyi University of Technology (Chinhoyi)",
                "Women’s University in Africa (Harare)",
                "Bindura University of Science Education (Bindura)",
                "Great Zimbabwe University (Masvingo)",
                "Solusi University (Bulawayo)",
                "Harare Institute of Technology (Harare)",
                "Lupane State University (Lupane)",
                "Catholic University of Zimbabwe (Harare)",
                "Arrupe Jesuit University (Harare)",
                "Zimbabwe Ezekiel Guti University (Bindura)",
                "Manicaland State University of Applied Sciences (Mutare)",
                "Gwanda State University (Filabusi)",
                "Reformed Church University (Masvingo)",
                "Marondera University of Agricultural Sciences and Technology (Marondera)",
            ]
        

        for dept in institution:
            Institution.objects.create(instName=dept)

        self.stdout.write(self.style.SUCCESS("Successfully loaded institutions"))
