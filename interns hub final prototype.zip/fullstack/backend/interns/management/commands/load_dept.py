from django.core.management.base import BaseCommand
from interns.models import Departments


class Command(BaseCommand):
    help = "Load departments into the database"

    def handle(self, *args, **kwargs):
        departments = [
            "Computer Engineering",
            "Accounting and Information Systems",
            "Banking and Finance",
            "Management Studies",
            "Economics",
            "Graduate Business School",
            "Technology",
            "Agriculture",
            "Commerce",
            "Applied Social Sciences",
            "Arts, Culture and Heritage Studies",
            "Science",
            "Law",
            "Education",
            "Agriculture Environment",
            "Arts And Humanities",
            "Business Management",
            "Veterinary Science",
        ]

        for dept in departments:
            Departments.objects.create(deptName=dept)

        self.stdout.write(self.style.SUCCESS("Successfully loaded departments"))
