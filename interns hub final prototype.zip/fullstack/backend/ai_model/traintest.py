import pandas as pd
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import pickle

# Load the dataset
df = pd.read_csv("student_projects0.csv")

# Define the features (study program) and target (recommended project)
X = df[["program"]]
y = df["description"]

# Encode the study program column
le = LabelEncoder()
X.loc[:, "program"] = le.fit_transform(X["program"])

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)


# Create a Random Forest classifier
rf = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model on the entire dataset
rf.fit(X, y)
# Make predictions on the test data
y_pred = rf.predict(X_test)

# Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f"accuracy : {accuracy:.3f}")
# Save the model
model_filename = "model_rf.pkl"
with open(model_filename, "wb") as file:
    pickle.dump((le, rf), file)


def recommend_projects(study_program, num_projects=3):
    study_program_encoded = le.transform([study_program])
    X_new = pd.DataFrame({"program": study_program_encoded})
    predicted_probabilities = rf.predict_proba(X_new)  # Get class probabilities
    top_project_indices = predicted_probabilities.argsort()[0, ::-1][:num_projects]
    recommended_projects = [y[i] for i in top_project_indices]
    return recommended_projects


# Example usage:
study_program = "Software Engineering"
recommended_projects = recommend_projects(study_program, num_projects=3)
print(f"Top 3 recommended projects for study program '{study_program}':")
for project in recommended_projects:
    print(project)
