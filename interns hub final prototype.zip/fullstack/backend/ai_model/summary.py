import pandas as pd
import spacy
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import classification_report
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

nltk.download("stopwords")
nltk.download("punkt")


def preprocess(text):
    # Convert text to lowercase
    text = text.lower()

    # Tokenize the text
    tokens = word_tokenize(text)

    # Remove stopwords
    stop_words = set(stopwords.words("english"))
    filtered_tokens = [token for token in tokens if token not in stop_words]

    # Join the tokens back into a string
    preprocessed_text = " ".join(filtered_tokens)

    return preprocessed_text


# Load the spaCy model
nlp = spacy.load("en_core_web_sm")

# Load and preprocess the dataset
dataset = pd.read_csv("summary.csv")
preprocessed_descriptions = preprocess(dataset["project_description"])

# Extract features using spaCy
features = []
for description in preprocessed_descriptions:
    doc = nlp(description)
    extracted_features = [token.text for token in doc.ents if token.label_ == "SKILL"]
    features.append(" ".join(extracted_features))

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    features, dataset["skill_label"], test_size=0.2, random_state=42
)

# Initialize and train the SVM model
svm_model = SVC()
svm_model.fit(X_train, y_train)

# Evaluate the model
y_pred = svm_model.predict(X_test)
print(classification_report(y_test, y_pred))

# Example usage
new_description = "Developed a web application using Python and Django."
preprocessed_description = preprocess(new_description)
doc = nlp(preprocessed_description)
extracted_skills = [token.text for token in doc.ents if token.label_ == "SKILL"]
predicted_skills = svm_model.predict([" ".join(extracted_skills)])
print("Predicted Skills:", predicted_skills)

""" Generate a synthetic dataset of student project descriptions.

Dataset Schema:
- project_description: string

Instructions:
1. Create a tabular dataset with the specified schema.
2. Generate synthetic data that represents various student project descriptions.
3. Ensure that the generated data is suitable for training a machine learning model.
4. The project_description column should contain realistic project descriptions that students might provide for their projects.
5. The descriptions can include technical details, methodologies, tools used, and any other relevant information.

Example Output (CSV format):
project_description
Developed a web application using Python and Django. Used HTML, CSS, and JavaScript for the front-end. Integrated a PostgreSQL database for data storage."""
