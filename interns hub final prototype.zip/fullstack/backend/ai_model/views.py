import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pickle

# Load the dataset
df = pd.read_csv("mixed.csv")

# Create a TF-IDF vectorizer
vectorizer = TfidfVectorizer()

# Create a matrix of study program descriptions
study_program_matrix = vectorizer.fit_transform(df["study_program"])

# Compute cosine similarity between study programs
similarity_matrix = cosine_similarity(study_program_matrix)

# Save the model
model_filename = "recommendation_model.pkl"
with open(model_filename, "wb") as file:
    pickle.dump((vectorizer, similarity_matrix, df), file)


# Function to make recommendations based on study program
def recommend_projects(study_program, top_n=5):
    # Load the model
    with open(model_filename, "rb") as file:
        vectorizer, similarity_matrix, df = pickle.load(file)

    # Find the index of the given study program
    study_program_index = df[df["study_program"] == study_program].index[0]

    # Get the similarity scores for the given study program
    study_program_similarities = similarity_matrix[study_program_index]

    # Sort the similarity scores in descending order
    sorted_indices = study_program_similarities.argsort()[::-1]

    # Get the top recommended projects
    top_projects = df.loc[sorted_indices[:top_n], "project_description"]

    return top_projects.tolist()


# Make recommendations for a specific study program
study_program = "Accounting"
recommended_projects = recommend_projects(study_program)

print(f"Top recommended projects for study program '{study_program}':")
for project_description in recommended_projects:
    print(f"- {project_description}")
