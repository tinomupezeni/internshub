import React, { useEffect, useState } from "react";
import "./Ai.css";
import Server from "../../Hero/Server";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSync } from "@fortawesome/free-solid-svg-icons";
import Button from "react-bootstrap/esm/Button";
import { useNavigate } from "react-router-dom";

const ProjectsAi = () => {
  const [proj, setProjects] = useState([]);
  const [errorMsg, setErrorMsg] = useState(null);
  const [userErrorMsg, setUserErrorMsg] = useState(null);
  const [userSetProg, setUserSetProg] = useState(null);

  const [isLoading, setIsLoading] = useState(false);
  let navigate = useNavigate();
  const fetchData = () => {
    setIsLoading(true);
    setErrorMsg(null);
    setProjects([]);
    Server.getstudentAiProjects()
      .then((response) => {
        setProjects(response.data.projects);
        setUserSetProg(response.data.message);
        setIsLoading(false);
        setErrorMsg(null);
      })
      .catch((error) => {
        setIsLoading(false);
        if (error.response) {
          if (error.response.status === 401) {
            navigate("/login");
          } else if (error.response.status === 404) {
            setUserErrorMsg(error.response.data.error);
          } else {
            setErrorMsg("Something went wrong, please try again.");
          }
        } else {
          setErrorMsg("Network error, please try again.");
        }
      });
  };

  useEffect(fetchData, []);

  return (
    <div className="projects-ai">
      <div>
        {errorMsg && (
          <p className="alert alert-danger" role="alert">
            {errorMsg}
          </p>
        )}

        {proj && (
          <ul>
            <p className="alert alert-info text-center" role="alert">
              {userSetProg ? userSetProg : "cooking"}
            </p>
            {isLoading && (
              <div
                style={{
                  alignItems: "center",
                  textAlign: "center",
                  justifyContent: "center",
                }}
              >
                <div class="d-flex justify-content-center align-items-center">
                  <div
                    className="spinner-border text-primary"
                    role="status"
                    style={{ width: "2rem", height: "2rem" }}
                  >
                    <span class="visually-hidden"></span>
                  </div>
                </div>
                <p>
                  <b>generating projects...</b>
                </p>
              </div>
            )}
            {userErrorMsg && <p>{userErrorMsg}</p>}
            {proj.map((project) => {
              return <li>{project}</li>;
            })}
            <Button
              style={{ margin: "0 auto", width: "100%" }}
              onClick={fetchData}
            >
              refresh <FontAwesomeIcon icon={faSync} />
            </Button>
          </ul>
        )}
      </div>
    </div>
  );
};

export default ProjectsAi;
