import React, { useState, useEffect, useRef } from "react";
import secureLocalStorage from "react-secure-storage";
import Dropzone from "dropzone";
import axios from "axios"; // For API requests

const API_URL = "http://localhost:8000/";

const UploadPdf = () => {
  const loggedInData = secureLocalStorage.getItem("loggedInStudent");
  const uploadRef = useRef(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadError, setUploadError] = useState(null);
  const [csrfToken, setCsrfToken] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const uploadUrl = "student/upload-cv/";
  const [uploadSuccess, setUploadSuccess] = useState(null);
  const [state, setState] = useState({
    errorMsg: "",
    successMsg: "",
    myDropzoneInst: null,
    isMyDropzoneReady: false,
  });

  const onDrop = async (acceptedFiles) => {
    const formData = new FormData();
    formData.append("file", acceptedFiles[0]);

    try {
      await axios.post(API_URL + uploadUrl, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          "X-CSRFToken": csrfToken,
          Authorization: `Bearer ${loggedInData.token}`,
        },
      });

      setUploadedFile(acceptedFiles[0]);
      setUploadError(null);
    } catch (error) {
      setUploadError("An error occurred during upload. Please try again.");
    }
  };

  useEffect(() => {
    const myDropzone = new Dropzone(uploadRef.current, {
      headers: {
        "X-Requested-With": null,
        Authorization: `Bearer ${loggedInData.token}`,
      },
      url: API_URL + uploadUrl,
      acceptedFiles: ".pdf",
      maxFiles: 1,
      parallelUploads: 1,
      addRemoveLinks: true,
      dictCancelUpload: "Cancel Upload",
      dictRemoveFile: "Remove File",
      chunking: false,

      // Call upload function on sending
      init: function () {
        this.on("sending", (file, xhr, formData) => {
          formData.append("X-CSRFToken", getCsrfToken());
          setState((prevState) => {
            return {
              ...prevState,
              uploading: true,
            };
          });
        });
        this.on("drop", onDrop);
      },
    });
    myDropzone.on("error", function (file, message) {
      setState((prevState) => {
        return {
          ...prevState,
          errorMsg: "troublesome network connection",
          uploading: false,
        };
      });
    });

    myDropzone.on("success", (file, response) => {
      setState((prevState) => {
        return {
          ...prevState,
          uploading: false,
          successMsg: response.message,
        };
      });
    });

    setState((prevState) => {
      return {
        ...prevState,
        myDropzoneInst: myDropzone,
      };
    });
    setState((prevState) => {
      return {
        ...prevState,
        isMyDropzoneReady: true,
      };
    });

    return () => {
      myDropzone.destroy();
      setIsLoading(false);
    };

    getCsrfToken();
    return () => {
      myDropzone.destroy();
    };
  }, []);

  const getCsrfToken = async () => {
    try {
      const response = await axios.get(API_URL + "student/upload-cv/token/");
      setCsrfToken(response.data.csrf_token);
      return response.data.csrf_token;
    } catch (error) {
      return null;
    }
  };

  return (
    <div className="dropzone-container">
      <div className="dropzone-container">
        {state.errorMsg && (
          <p className="alert alert-danger" role="alert">
            {state.errorMsg}
          </p>
        )}
        {state.successMsg && (
          <p className="alert alert-success text-center" role="alert">
            {state.successMsg}
          </p>
        )}
        {!state.uploading && (
          <div ref={uploadRef} className="dropzone">
            <p className="alert alert-info" role="alert">
              click to select a video to upload,
              <br /> <b>don't drop, select</b>{" "}
            </p>
          </div>
        )}
        {state.uploading && (
          <div
            style={{
              alignItems: "center",
              textAlign: "center",
              justifyContent: "center",
            }}
            className="alert alert-success text-center"
          >
            <div
              class="d-flex justify-content-center align-items-center"
              style={{
                height: "50px",
              }}
            >
              <div className="spinner-border text-primary" role="status">
                <span class="visually-hidden"></span>
              </div>
            </div>
            <p>
              <b>processing your project...</b>
            </p>
          </div>
        )}
        {uploadSuccess && (
          <p className="alert alert-success text-center" role="alert">
            {uploadSuccess}
          </p>
        )}
        {uploadedFile && (
          <p className="alert alert-danger" role="alert">
            {" "}
            File uploaded: {uploadedFile.name}
          </p>
        )}
        {uploadError && (
          <p className="alert alert-danger" role="alert">
            {uploadError}
          </p>
        )}
      </div>
    </div>
  );
};

export default UploadPdf;
