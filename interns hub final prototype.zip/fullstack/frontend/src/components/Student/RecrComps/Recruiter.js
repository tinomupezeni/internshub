import React, { useEffect, useState } from "react";
import secureLocalStorage from "react-secure-storage";
import "./Recruiter.css";
import Server from "../../Hero/Server";
import { useNavigate } from "react-router-dom";
import { faIndustry, faUserGraduate } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function Recruiter() {
  let navigate = useNavigate();
  const [state, setState] = useState({
    companies: [],
    errorMsg: "",
  });
  const studentProfileData = secureLocalStorage.getItem("studentProfileData");

  useEffect(() => {
    Server.getstudentComps().then(
      (response) => {
        console.log(response.data);
        setState((prevState) => {
          return {
            ...prevState,
            companies: response.data,
          };
        });
      },
      (error) => {
        if (error.response && error.response.status === 401) {
          navigate("/log-in");
        }
        setState((prevState) => {
          return {
            ...prevState,
            errorMsg: "an error occured",
          };
        });
      }
    );
  }, []);
  return (
    <>
      <div className="recruiter">
        <h1>Companies in {studentProfileData.student_profile.department}</h1>
        <p>
          Dive in and explore the exciting opportunities waiting for you!
          Discover the key requirements set by leading companies in your field.
        </p>
        {state.errorMsg && (
          <p className="alert alert-danger text-center" role="alert">
            {state.errorMsg}
          </p>
        )}
        <div className="company data-collection">
          <div className="ava-depts">
            {state.companies.length > 0 ? (
              state.companies.map((dep, deptIndex) => (
                <ul key={deptIndex}>
                  <div className="heading">
                    <i className="icon-comp-potfolio">
                      <FontAwesomeIcon icon={faIndustry} />
                    </i>
                    <div>
                      <h3>{dep.companyName}</h3>
                      <p style={{ textTransform: "none" }}>
                        <a
                          href={`mailto:${dep.companyEmail}`}
                          style={{ textTransform: "lowercase" }}
                        >
                          {dep.companyEmail}
                        </a>
                      </p>
                    </div>
                  </div>
                  <h5>requirements</h5>
                  <div style={{ marginLeft: "50px" }}>
                    {dep.requirements.map((req) => (
                      <p> - {req}</p>
                    ))}
                  </div>
                  <h5>relevant projects</h5>
                  <div style={{ marginLeft: "50px" }}>
                    {dep.projects.map((req) => (
                      <p className="alert alert-info">{req}</p>
                    ))}
                  </div>
                </ul>
              ))
            ) : (
              <p className="alert alert-info text-center">
                <b>
                  no companies in your department yet, but don't loss hope, keep
                  pushing your craft
                </b>
              </p>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
