import React, { useEffect, useState } from "react";
import "./InternPotfolio.css";
import Server from "../Hero/Server";
import VideoPlayer from "../Hero/VideoPlayer";
import secureLocalStorage from "react-secure-storage";
import { faUserGraduate } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

export default function InternPotfolio() {
  const [state, setState] = useState({
    projects: {},
  });

  useEffect(() => {
    const id = secureLocalStorage.getItem("studentId");
    Server.getInternPotfolio(id).then((response) => {
      console.log(response.data);
      setState((prevState) => {
        return {
          ...prevState,
          projects: response.data,
        };
      });
    });
  }, []);
  return (
    <>
      <div className="intern-potfolio">
        <div className="heading">
          <i className="icon-intern-potfolio">
            <FontAwesomeIcon icon={faUserGraduate} />
          </i>
          <div>
            <h1>
              {state.projects.name} {state.projects.surname}
            </h1>
            <p>
              <a
                href={`mailto:${state.projects.email}`}
                style={{ textTransform: "lowercase" }}
              >
                {state.projects.email}
              </a>
            </p>
            <p>{state.projects.program}</p>
            <p>{state.projects.institution}</p>
          </div>
        </div>
        {state.projects.cv ? (
          <div className="card">
            <div className="card-body">
              <div className="embed-responsive embed-responsive-16by9">
                <iframe
                  src={state.projects.cv}
                  width="100%"
                  height="500px"
                  title="Intern CV"
                />
              </div>
            </div>
          </div>
        ) : (
          <p>no curriculum vitae found for this student</p>
        )}
        <div className="available-projects">
          <h2>projects</h2>
          <MyProjects projects={state.projects.student_projects} />
        </div>
      </div>
    </>
  );
}

const MyProjects = ({ projects }) => {
  console.log(projects);
  return (
    <>
      <div className="interns">
        <div className="interns-data">
          {projects && projects.length > 0 ? (
            projects.map((intern, index) => (
              <ul>
                <div key={index} className="intern-video">
                  <div className="video">
                    <VideoPlayer link={intern.url} />
                  </div>
                  <div className="video-info card-footer">
                    <div>
                      <h4>{intern.project_name}</h4>
                      <p className="card-text">{intern.description}</p>
                    </div>
                  </div>
                </div>
              </ul>
            ))
          ) : (
            <div className="intern">
              <p className="alert alert-info text-center">No projects found</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
