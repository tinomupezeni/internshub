import React from 'react'
import StudentCvNav from '../components/navbar/StudentCvNav'
import Recruiter from '../components/Student/RecrComps/Recruiter'

export default function RecruitComp() {
  return (
    <>
    <StudentCvNav />
    <Recruiter />
    </>
  )
}
