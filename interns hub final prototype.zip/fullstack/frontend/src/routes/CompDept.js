import React from 'react'
import CompNavbar from '../components/navbar/CompNavbar'
import CompanyProfile from '../components/Company/CompanyProfile'

export default function CompDept() {
  return (
    <>
    <CompNavbar />
    <CompanyProfile />
    </>
  )
}
