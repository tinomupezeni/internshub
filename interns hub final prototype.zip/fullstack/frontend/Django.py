# generate pre-signed url to upload cv
from django.http import JsonResponse
import boto3

def presigned_url(request):
  s3_client = boto3.client('s3')
  file_name = request.GET.get('file_name')
  presigned_url = s3_client.generate_presigned_url('put_object', Params={'Bucket': 'your_bucket_name', 'Key': file_name}, ExpiresIn=3600)
  return JsonResponse({'url': presigned_url})
