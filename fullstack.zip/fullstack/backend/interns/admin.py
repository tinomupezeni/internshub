from django.contrib import admin
from .models import Student,  Company

admin.site.register(Student)
admin.site.register(Company)
# admin.site.register(Portfolio)
# admin.site.register(Department)
# admin.site.register(Requirement)
# admin.site.register(Skill)
# admin.site.register(InternSkill)
# admin.site.register(PortfolioSkill)
