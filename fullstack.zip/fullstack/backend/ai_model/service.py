import pandas as pd
from tensorflow.keras.preprocessing.sequence import pad_sequences
import tensorflow as tf
import pickle

# Load the saved model
model = tf.keras.models.load_model("study_program_to_project_model.h5")

# Load the tokenizer and label encoder
with open('tokenizer.pkl', 'rb') as handle:
    tokenizer = pickle.load(handle)

with open('label_encoder.pkl', 'rb') as handle:
    label_encoder = pickle.load(handle)

# Define max_length (should be the same as used during training)
max_length = 100

# Function to recommend projects based on study programs
def recommend_project(study_program):
    sequence = tokenizer.texts_to_sequences([study_program])
    padded_sequence = pad_sequences(sequence, maxlen=max_length, padding='post', truncating='post')
    prediction = model.predict(padded_sequence)
    project_id = prediction.argmax()
    project = label_encoder.inverse_transform([project_id])[0]
    return project

# Example usage
new_study_program = "Data Science"
recommended_project = recommend_project(new_study_program)
print(f"Recommended project for {new_study_program}: {recommended_project}")
