from sklearn.preprocessing import LabelEncoder
import torch.nn as nn
import torch
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import pandas as pd
from torch.utils.data import Dataset, DataLoader


# Define a custom Dataset
class StudentProjectDataset(Dataset):
    def __init__(self, programs, projects):
        self.programs = programs
        self.projects = projects

    def __len__(self):
        return len(self.programs)

    def __getitem__(self, idx):
        return self.programs[idx], self.projects[idx]


# Define the neural network model
class ProjectClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(ProjectClassifier, self).__init__()
        self.fc1 = nn.Linear(input_size, hidden_size)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_size, output_size)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        out = self.fc1(x)
        out = self.relu(out)
        out = self.fc2(out)
        out = self.softmax(out)
        return out


# Load and preprocess the dataset
data = pd.read_csv("projects_and_study_programs.csv")
programs = data["student_program"].values
projects = data["description"].values

# Encode the labels
program_encoder = LabelEncoder()
project_encoder = LabelEncoder()
encoded_programs = program_encoder.fit_transform(programs)
encoded_projects = project_encoder.fit_transform(projects)

# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(
    encoded_programs, encoded_projects, test_size=0.2, random_state=42
)

# Convert to PyTorch tensors
X_train = torch.tensor(X_train, dtype=torch.long)
y_train = torch.tensor(y_train, dtype=torch.long)
X_test = torch.tensor(X_test, dtype=torch.long)
y_test = torch.tensor(y_test, dtype=torch.long)

# Create DataLoader
train_dataset = StudentProjectDataset(X_train, y_train)
train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)

# Model parameters
input_size = len(program_encoder.classes_)
hidden_size = 128
output_size = len(project_encoder.classes_)
learning_rate = 0.001
num_epochs = 20

# Initialize the model, loss function and optimizer
model = ProjectClassifier(input_size, hidden_size, output_size)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# Training loop
for epoch in range(num_epochs):
    for programs, projects in train_loader:
        # One-hot encode the input
        programs_one_hot = torch.nn.functional.one_hot(
            programs, num_classes=input_size
        ).float()

        # Forward pass
        outputs = model(programs_one_hot)
        loss = criterion(outputs, projects)

        # Backward pass and optimization
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}")

# Evaluation
model.eval()
with torch.no_grad():
    X_test_one_hot = torch.nn.functional.one_hot(X_test, num_classes=input_size).float()
    outputs = model(X_test_one_hot)
    _, predicted = torch.max(outputs.data, 1)
    accuracy = accuracy_score(y_test.numpy(), predicted.numpy())
    print(f"Accuracy: {accuracy:.4f}")
