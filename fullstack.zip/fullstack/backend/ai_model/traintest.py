import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

# Load the dataset
df = pd.read_csv("student_projects0.csv")

# Define the features (study program) and target (recommended project)
X = df[["program"]]
y = df["description"]

# Encode the study program column
le = LabelEncoder()
X.loc[:, "program"] = le.fit_transform(X["program"])

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Create a Random Forest classifier
rf = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the model on the training data
rf.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = rf.predict(X_test)

# Evaluate the model's performance
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.3f}")


# Use the trained model to make recommendations for new students
def recommend_projects(study_program, num_projects):
    study_program_encoded = le.transform([study_program])
    X_new = pd.DataFrame({"program": study_program_encoded})
    predicted_projects = rf.predict(X_new)
    recommended_projects = predicted_projects[:num_projects]
    return recommended_projects.tolist()


# Example usage:
study_program = "Law"
num_projects = 3
recommended_projects = recommend_projects(study_program, num_projects)
print(f"Recommended projects for {study_program}:")
for project in recommended_projects:
    print(project)
