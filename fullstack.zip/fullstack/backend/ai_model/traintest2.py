import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from pandas.core.dtypes.missing import isna

# Load the dataset containing projects and their descriptions
df = pd.read_csv("mixed.csv")

# Preprocess the project descriptions
vectorizer = TfidfVectorizer(stop_words="english")

project_descriptions = vectorizer.fit_transform(df["project"])
from pandas.core.dtypes.missing import isna


def get_recommendations(student_program, company_requirements, top_n=5):
    # Preprocess the student program and company requirements
    query = vectorizer.transform([student_program, company_requirements])

    # Compute the cosine similarity between the query and project descriptions
    cosine_similarities = cosine_similarity(query, project_descriptions)

    # Compute the average cosine similarity for each project
    average_similarities = cosine_similarities.mean(axis=0)

    # Get the indices of the top-n most similar projects
    top_indices = average_similarities.argsort()[: -top_n - 1 : -1]

    # Get the top recommended projects
    top_projects = df.loc[top_indices[:top_n], "project"]

    # Filter out duplicate projects
    unique_projects = []
    for project in top_projects:
        if project not in unique_projects:
            unique_projects.append(project)

    # Return the recommended projects
    return unique_projects[:3]  # Return the top 3 projects


# Example usage
student_program = "Software Engineering"
company_requirements = "We are looking for a project related to machine learning and natural language processing."
recommended_projects = get_recommendations(student_program, company_requirements)

print(f"Top 3 recommended projects for study program '{student_program}':")
for project_description in recommended_projects:
    print(f"- {project_description}")
