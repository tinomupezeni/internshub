import keras
import numpy as np
from keras import preprocessing
from tensorflow.keras.preprocessing.text import Tokenizer  # type: ignore
from keras.callbacks import EarlyStopping, ModelCheckpoint  # type: ignore
from keras.layers import Dropout  # type: ignore
from keras import layers
from tensorflow.keras.optimizers import Adam  # type: ignore
from dataset import descriptions
from tensorflow.keras import layers  # type: ignore
from tensorflow.keras.models import Model  # type: ignore

# Tokenize the text
tokenizer = Tokenizer()
tokenizer.fit_on_texts(descriptions)
sequences = tokenizer.texts_to_sequences(descriptions)

# Prepare the sequences for training
X = []
y = []
for sequence in sequences:
    for i in range(1, len(sequence)):
        X.append(sequence[:i])
        y.append(sequence[i])
X = preprocessing.sequence.pad_sequences(
    X, maxlen=max(len(sequence) for sequence in sequences)
)
y = np.array(y)


# Define the Transformer block
class TransformerBlock(layers.Layer):
    def __init__(self, embed_dim, num_heads, ff_dim, rate=0.1):
        super(TransformerBlock, self).__init__()
        self.att = layers.MultiHeadAttention(num_heads=num_heads, key_dim=embed_dim)
        self.ffn = keras.Sequential(
            [
                layers.Dense(ff_dim, activation="relu"),
                layers.Dense(embed_dim),
            ]
        )
        self.layernorm1 = layers.LayerNormalization(epsilon=1e-6)
        self.layernorm2 = layers.LayerNormalization(epsilon=1e-6)
        self.dropout1 = layers.Dropout(rate)
        self.dropout2 = layers.Dropout(rate)

    def call(self, inputs, training=False):
        attn_output = self.att(inputs, inputs)
        attn_output = self.dropout1(attn_output, training=training)
        out1 = self.layernorm1(inputs + attn_output)
        ffn_output = self.ffn(out1)
        ffn_output = self.dropout2(ffn_output, training=training)
        return self.layernorm2(out1 + ffn_output)


maxlen = max(len(sequence) for sequence in sequences)

# Define the model
inputs = layers.Input(shape=(maxlen,))
embedding_layer = layers.Embedding(
    input_dim=len(tokenizer.word_index) + 1, output_dim=200, input_length=X.shape[1]
)(inputs)
transformer_block = TransformerBlock(200, 2, 512)
x = transformer_block(embedding_layer, training=True)
x = layers.GlobalAveragePooling1D()(x)
x = layers.Dropout(0.01)(x)
x = layers.Dense(30, activation="relu")(x)
x = layers.Dropout(0.01)(x)
outputs = layers.Dense(len(tokenizer.word_index) + 1, activation="softmax")(x)

model = Model(inputs=inputs, outputs=outputs)
# model.load_weights("projects_flex.keras")


# Compile the model
model.compile(
    loss="sparse_categorical_crossentropy", optimizer=Adam(), metrics=["accuracy"]
)

# ... (same as before)

# Define callbacks
early_stopping = EarlyStopping(monitor="val_loss", patience=5)
model_checkpoint = ModelCheckpoint(
    "best_model.keras", save_best_only=True, monitor="val_loss"
)

# Train the model with callbacks
history = model.fit(
    X,
    y,
    epochs=20,
    validation_split=0.2,
    callbacks=[early_stopping, model_checkpoint],
)


# Evaluate the model
loss, accuracy = model.evaluate(X, y)
print(f"Loss: {loss}")
print(f"Accuracy: {accuracy}")

# Save the model
model.save("projects_flex.keras")


# Function to generate text
def generate_text(seed_text, num_words, temperature=1.0):
    for _ in range(num_words):
        # Tokenize the seed text
        sequence = tokenizer.texts_to_sequences([seed_text])[0]
        sequence = preprocessing.sequence.pad_sequences([sequence], maxlen=X.shape[1])

        # Use the model to predict the next word
        predictions = model.predict(sequence)[0]

        # Apply the temperature parameter to the predictions
        predictions = np.asarray(predictions).astype("float64")
        predictions = np.exp(np.log(predictions + 1e-10) / temperature)
        predictions = predictions / np.sum(predictions)

        # Sample the next word index from the probability array
        probas = np.random.multinomial(1, predictions, 1)
        next_word_index = np.argmax(probas)

        # Append the predicted word to the seed text
        for word, index in tokenizer.word_index.items():
            if index == next_word_index:
                seed_text += " " + word
                break

    return seed_text


def generate_project(model, seed_text=None, num_words=50, temperature=1.0):
    if seed_text is None:
        # If no seed text is provided, start with a generic prompt
        seed_text = "A project for an internship student could be..."

    project = generate_text(seed_text, num_words, temperature)

    return project

    # Generate three project descriptions
    # for _ in range(3):
# seed_text = "A project for a software engineering student could be..."
print(generate_project(model))
