Security Policy
===============

Supported Versions
------------------

Only the latest release is supported

Reporting a Vulnerability
-------------------------

Low impact vulnerabilities, e.g. DoS, can be reported directly to the issue tracker.

Severe vulnerabilities can be reported via E-Mail:

* https://hboeck.de/en/contact.html
