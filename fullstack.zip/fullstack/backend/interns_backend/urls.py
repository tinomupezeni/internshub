from django.urls import path
from django.contrib import admin
from interns.views.companies.companylogin import login_company
from interns.views.students.studentlogin import login_student
from interns.views.companies.companyviews import signup_company
from interns.views.students.studentview import signup_student
from interns.views.students.fetchcv import download_pdf
from interns.views.students.uploadcv import upload_pdf
from interns.views.students.studentsettings import settings_student
from interns.views.students.getstudentprofile import get_student_profile
from interns.views.students.fetchproject import get_videos
from interns.views.students.getprofileviews import get_profile_views

from interns.views.csrftoken import get_csrf_token
from interns.views.companies.adddepart import add_department
from interns.views.companies.getdept import get_compdept_data, get_alldepts_data
from interns.views.companies.deletedept import delete_department
from interns.views.companies.updaterequirements import update_requirements
from interns.views.companies.deletereq import delete_requirement
from interns.views.companies.getinterns import get_interns_data
from interns.views.students.uploadvid import upload_video
from interns.views.students.getstudentcomps import get_company_data
from interns.views.aikeyview import get_projects_data
from interns.views.companies.getpotfolio import get_interns_potfolio
from interns.views.companies.addprofileviews import add_or_update_profile_view

from interns.views.aimodel import predict_view

# verify email
from interns.views.sendverifcode import send_verification_code
from interns.views.verifycode import verify_code
from interns.views.loginverifcode import (
    send_student_login_code,
    verify_student_login_code,
)
from interns.views.compverifcode import comp_login_code, verify_comp_login_code

# logout
from interns.views.students.studentlogout import logout_student

urlpatterns = [
    path("admin/", admin.site.urls),
    path("signup/student/", signup_student, name="signup_student"),
    path("login/student/", login_student, name="login_student"),
    path("student/cv/", download_pdf, name="fetch_cv"),
    path("student/upload-cv/", upload_pdf, name="upload_cv"),
    path("student/upload-project/", upload_video, name="upload_vid"),
    path("student/get-projects/", get_videos, name="get_vid"),
    path("student/upload-cv/token/", get_csrf_token, name="upload_cv_token"),
    path("student/profile/settings/", settings_student, name="set-settings"),
    path("student/profile/get-settings/", get_student_profile, name="get-settings"),
    path("student/get-companies/", get_company_data, name="get-student-companies"),
    path("student/get-ai-projects/", predict_view, name="get-student-projects"),
    path("student/get-profile-views/", get_profile_views, name="get-student-projects"),
    path(
        "student/send-login-code/",
        send_student_login_code,
        name="-comp",
    ),
    path(
        "student/verify-login-code/",
        verify_student_login_code,
        name="verify-phone-code",
    ),
    # -----------------companiesA
    path("login/company/", login_company, name="login_company"),
    path("signup/company/", signup_company, name="signup_company"),
    path("company/add-department/", add_department, name="add_department"),
    path("company/get-department/", get_compdept_data, name="add_department"),
    path("company/get-all-departments/", get_alldepts_data, name="add_department"),
    path(
        "company/delete-department/<int:dept_id>/",
        delete_department,
        name="delete_department",
    ),
    path(
        "company/delete-requirement/<int:req_id>/",
        delete_requirement,
        name="delete_requiremnt",
    ),
    path(
        "company/add-profile-view/<int:student_id>/",
        add_or_update_profile_view,
        name="delete_requiremnt",
    ),
    path(
        "company/update-requirements/",
        update_requirements,
        name="update_department",
    ),
    path(
        "company/department/interns/",
        get_interns_data,
        name="departmeny_interns",
    ),
    path(
        "company/intern-potfolio/<int:studentId>/",
        get_interns_potfolio,
        name="get-potfolio",
    ),
    # log out
    path(
        "user/logout/",
        logout_student,
        name="logout_student",
    ),
    path(
        "user/send-verification-code/",
        send_verification_code,
        name="send-verify-code",
    ),
    path(
        "user/verify-email-code/",
        verify_code,
        name="verify-code",
    ),
    path(
        "company/send-login-code/",
        comp_login_code,
        name="send-verify-code-login-comp",
    ),
    path(
        "company/verify-login-code/",
        verify_comp_login_code,
        name="verify-phone-code",
    ),
]
