// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBeMp0_db_sQ2OcIr72n_e2pAUtkbjYrEs",
  authDomain: "internshub-f027a.firebaseapp.com",
  projectId: "internshub-f027a",
  storageBucket: "internshub-f027a.appspot.com",
  messagingSenderId: "328884513129",
  appId: "1:328884513129:web:06f839588fa4722256f5f8",
  measurementId: "G-BM31EDG90Z"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);