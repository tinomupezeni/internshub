import React, { useState } from "react";
import "./Student.css";

import CV from "./Cv/CV";
import secureLocalStorage from "react-secure-storage";

export default function Student() {
  const loggedInData = secureLocalStorage.getItem("loggedInData");
  return (
    <>
      <div className="student">
        <div className="student-heading">
          <h1>Welcome, {loggedInData.name}!</h1>
          <p style={{ width: "80%", margin: "0 auto" }}>
            Get ready to unleash your creativity! Go ahead and upload, tweak,
            and share your latest masterpiece. We're on the edge of our seats,
            thrilled to see the amazing things you'll create! Let's set the
            digital world ablaze with your talent!
          </p>
        </div>
        <CV />
      </div>
    </>
  );
}
