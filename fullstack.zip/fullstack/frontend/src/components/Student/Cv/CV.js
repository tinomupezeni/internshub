import React, { useState, useEffect } from "react";
import { Document, Page } from "@react-pdf/renderer";
import axios from "axios";
import secureLocalStorage from "react-secure-storage";
import "./CV.css";
import UploadPdf from "../Ai/UploadPdf";
// import { useUser } from "../../Hero/UserProvider";

const API_URL = "http://localhost:8000/";

export default function CV() {
  const loggedInData = secureLocalStorage.getItem("loggedInData");
  const [pdfUrl, setPdfUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setError] = useState(null);
  const [uploadCv, setUploadCv] = useState(false);
  // const {} = useUser();

  const previewCv = () => {
    setUploadCv(!uploadCv);
  };
  const fetchPDF = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get(API_URL + "student/cv/", {
        headers: {
          Authorization: `Bearer ${loggedInData.token}`,
        },
      });
      console.log(response);
      if (response.status === 200) {
        setPdfUrl(response.data.presigned_url);
      } else if (response.status === 500) {
        setError("no cv present");
      } else {
        setError("An error occurred while fetching the PDF.");
      }
    } catch (err) {
      setError(
        "Heads up! We noticed you haven't uploaded your CV yet. As an aspiring intern ready to make a mark in the professional world, having a CV is crucial. It's your chance to showcase your skills, experiences, and ambitions. Don't miss out on exciting internship opportunities - upload your CV now!"
      );
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchPDF();
  }, []);

  return (
    <>
      <div className="cv">
        <div style={{ margin: "auto" }}>
          {errorMsg && (
            <div className="alert alert-info text-center" role="alert">
              {errorMsg}
            </div>
          )}
        </div>

        {uploadCv ? (
          <UploadPdf />
        ) : (
          <ViewCv isLoading={isLoading} pdfUrl={pdfUrl} />
        )}
        <button
          onClick={previewCv}
          className="cv-preview btn btn-info position-fixed bottom-0 end-0 m-3"
        >
          {!uploadCv ? "upload cv" : "view-cv"}
        </button>
      </div>
    </>
  );
}

const ViewCv = ({ isLoading, error, pdfUrl }) => {
  return (
    <div>
      {isLoading && (
        <p>
          fetching your cv{" "}
          <span
            className={`spinner-border spinner-border-sm ${
              isLoading ? "" : "d-none"
            }`}
            role="status"
            aria-hidden="true"
          ></span>
        </p>
      )}
      {error && <p>Error: {error}</p>}
      {pdfUrl && (
        <div className="card">
          <div className="card-body">
            <div className="embed-responsive embed-responsive-16by9">
              <iframe
                src={pdfUrl}
                width="100%"
                height="500px"
                title="Intern CV"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
